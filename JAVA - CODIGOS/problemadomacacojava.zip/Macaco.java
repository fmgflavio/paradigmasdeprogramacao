import java.lang.Math;

public class Macaco{
    
    public int[][] montaSala(){
      int configsala[][] = new int[10][10];;
      int x_caixa = 3, y_caixa = 8;

      //1 = macaco
      //2 = banana
      //3 = caixa
      for(int i=0; i<10; i++){
          for(int j=0; j<10; j++){
              //aloca o macaco na posição 0,0
              if(i==0 && j==0){
                  configsala[i][j] = 1;
              }else{
                  //aloca a banana no centro da sala
                  if(i==(10/2)-1 && j==(10/2)-1){
                      configsala[i][j] = 2;
                  }else{
                      //aloca a caixa na sala
                      if(i==x_caixa && j==y_caixa){
                          configsala[i][j] = 3;
                      }else{
                          configsala[i][j] = 0;
                      }
                  }
              }
          }
      }
      return configsala;
    }
    
  void solucao(int sala[][], int x_caixa, int y_caixa){
    int distancia_caixa_x = x_caixa;
    int distancia_caixa_y = y_caixa;

    for(int i=1; i<=distancia_caixa_x; i++){
        //anda para frente no eixo x
        sala[i][0] = 1;
        System.out.println("O macaco deu um passo para frente. Posição atual: [" + i + "][0]\n");
    }

    for(int i=1; i<=distancia_caixa_y; i++){
        //anda para frente no eixo x
        sala[distancia_caixa_x][i] = 1;
        System.out.println("O macaco deu um passo para a esquerda. Posição atual: [" + distancia_caixa_x + "][" + i + "]\n");
    }

    System.out.println("O macaco chegou na caixa!\n");

    int distancia_banana_x = x_caixa - ((10/2)-1);
    int distancia_banana_y = y_caixa - ((10/2)-1);
    
    //o macaco precisa voltar
    if(distancia_banana_x > 0){
        for(int i=Math.abs(distancia_banana_x); i>0; i--){
            sala[distancia_caixa_x--][distancia_caixa_y] = 1;
            System.out.println("O macaco empurrou a caixa para trás. Posição atual: [" + distancia_caixa_x + "][" + distancia_caixa_y + "\n");
        }
    }else{
        if(distancia_banana_x < 0){
            //o macaco precisa andar para frente
            for(int i=1; i<=Math.abs(distancia_banana_x); i++){
                sala[distancia_caixa_x++][distancia_caixa_y] = 1;
                System.out.println("O macaco empurrou a caixa para frente. Posição atual: [" + distancia_caixa_x + "][" + distancia_caixa_y + "]\n");
            }
        }
    }

    //o macaco precisa voltar
    if(distancia_banana_y > 0){
        for(int i= Math.abs(distancia_banana_y); i>0; i--){
            sala[distancia_caixa_x][distancia_caixa_y--] = 1;
            System.out.println("O macaco empurrou a caixa para direita. Posição atual: [" + distancia_caixa_x +"][" + distancia_caixa_y + "]\n");
        }
    } else{
        if(distancia_banana_y < 0){
            //o macaco precisa andar para frente
            for(int i=1; i<=Math.abs(distancia_banana_y); i++){
                sala[distancia_caixa_x][distancia_caixa_y++] = 1;
                System.out.println("O macaco empurrou a caixa para esquerda. Posição atual: [" + distancia_caixa_x +"][" + distancia_caixa_y + "]\n");
            }
        }
    }
    System.out.println("O macaco subiu na caixa!\n");
    System.out.println("O macaco acertou a banana com o bastão! \n");
    System.out.println("O macaco pegou a banana!\n");
  }
    
}