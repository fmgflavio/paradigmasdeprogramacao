public class Main {
  public static void main(String[] args) {
    int sala[][] = new int[10][10];
    System.out.println("Problema do macaco e da banana!");
    Macaco M1 = new Macaco(); 
	
    sala = M1.montaSala();

    M1.solucao(sala, 3, 8);
  }
}