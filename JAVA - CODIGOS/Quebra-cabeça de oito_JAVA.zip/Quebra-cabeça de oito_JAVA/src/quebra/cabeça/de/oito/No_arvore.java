/*
 *  CIC133 -- PARADIGMAS DE PROGRAMAÇÃO -- PROJETO FINAL
 *  Quebra-cabeça de oito - JAVA -- Branch and Bound
 *
 */
package quebra.cabeça.de.oito;

/**
 *
 * @author Flavio Mota Gomes - 2018005379
 *         Rafael Antunes Vieira - 2018000980
 *         Rafael Greca Vieira - 2018000434
 */
public class No_arvore {

    public No_arvore pai;
    public int[][] matriz;

    // Coordenadas vazias
    public int x, y;

    // variavel que recebe o custo
    public int custo;

    // variavel que recebe a etapa 
    public int nivel_arvore;

    public No_arvore(int[][] matriz, int x, int y, int Xaux, int Yaux, int nivel_arvore, No_arvore pai) {
        this.pai = pai;
        this.matriz = new int[matriz.length][];
        for (int i = 0; i < matriz.length; i++) {
            this.matriz[i] = matriz[i].clone();
        }

        // Faz a troca dos valores
        this.matriz[x][y] = this.matriz[x][y] + this.matriz[Xaux][Yaux];
        this.matriz[Xaux][Yaux] = this.matriz[x][y] - this.matriz[Xaux][Yaux];
        this.matriz[x][y] = this.matriz[x][y] - this.matriz[Xaux][Yaux];

        // Calcula os novos custos de acordo com o nivel da arvore
        this.custo = Integer.MAX_VALUE;
        this.nivel_arvore = nivel_arvore;
        this.x = Xaux;
        this.y = Yaux;
    }

}
