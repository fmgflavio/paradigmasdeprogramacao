/*
 *  CIC133 -- PARADIGMAS DE PROGRAMAÇÃO -- PROJETO FINAL
 *  Quebra -  Cabeça de oito - JAVA - Branch and Bound
 *
 * @authors Flavio Mota Gomes - 2018005379 
 *          Rafael Antunes Vieira - 2018000980
 *          Rafael Greca Vieira - 2018000434
 * 
 */

// Pacote em que o arquivo está 
package quebra.cabeça.de.oito;

// Bibliotecas necessarias 
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

// Classe principal do quebra cabeça
public class quebra_cabeca {

    // tamanho da matriz 
    public int tamanho_matriz = 3;

    // opções de movimentos na coluna e na linha
    int[] linha = {1, 0, -1, 0};
    int[] coluna = {0, -1, 0, 1};
    
    // Metodo que imprime a matriz com os numeros
    public void imprime(int[][] matriz) {
        for (int[] vet_aux : matriz) {
            for (int j = 0; j < matriz.length; j++) {
                System.out.print(vet_aux[j] + " ");
            }
            System.out.println();
        }
    }
    
    // Imprimir o caminho do nó raiz até  nó de destino de forma recursiva
    public void imprime_caminho_recursivo(No_arvore raiz) {
        // se a raiz for igual a NULL, quer dizer que chegou no final ou não existe
        if (raiz == null) {
            return;
        }
        // Chama novamente a função passsando o nó raiz anterior 
        imprime_caminho_recursivo(raiz.pai);
        // imprime o nó atual da matriz
        imprime(raiz.matriz);
        // Espaco entre os numeros ( estetica )
        System.out.println();
    }
    
    // Verifica se a posição existe dentro da matriz
    public boolean verifica_posicao_matriz(int x, int y) {
        // Verifica se não estourou as dimenções da matriz
        if (x >= 0 && x < tamanho_matriz && y >= 0 && y < tamanho_matriz){
            return TRUE;
        }
        // Se estourou as dimenções da matriz, retorna false ( reprovado )
        else{
            return FALSE;
        }
    }

    // Função que efetua o calculo dos custos 
    public int calculo_dos_custos(int[][] inicio, int[][] fim) {
        // variavel que que quarda os custos
        int aux = 0;
        // percorre a matriz até o final coluna e linha
        for (int i = 0; i < inicio.length; i++) {
            for (int j = 0; j < inicio.length; j++) {
                // se inicio for diferente do bloco vazio e o elemento fina da matriz de estado incial 
                // for diferente da matriz do estado final acrecenta 1 no custo
                if (inicio[i][j] != 0 && inicio[i][j] != fim[i][j]) {
                    aux++;
                }
            }
        }
        return aux;
    }
    
    // Metodo que verifica se os nós estão em seguencia
    public boolean sequencia(int[][] matriz) {
        // Define as variaveis
        int aux = 0;
        // Cria uma lista de inteiro
        List<Integer> array = new ArrayList<>();
        
        // Cria uma lista2 de inteiro
        Integer[] array2 = new Integer[array.size()];
        
        
        // Passa os valores da matriz para o array
        for (int[] vet_aux : matriz) {
            for (int j = 0; j < matriz.length; j++) {
                array.add(vet_aux[j]);
            }
        }
        
        // Passa os elementos convertidos em um unico array 
        array.toArray(array2);
        
        // Se não for o espaço em branco e estiver em ordem crescente incrementa 
        for (int i = 0; i < array2.length - 1; i++) {
            for (int j = i + 1; j < array2.length; j++) {
                if (array2[i] != 0 && array2[j] != 0 && array2[i] > array2[j]) {
                    aux++;
                }
            }
        }
        // retorna a posição do elemnto que quebra a regra
        return aux % 2 == 0;
    }
    
    // Metodo que gerencia toda a resoluçaõ do problema
    // Recebe as posições x e y estado inicial e o final 
    public void Resolucao(int[][] inicio, int[][] fim, int x, int y) {
        // Os objetos devem ser processados​com base na prioridade os que tiverem menos custos
        PriorityQueue<No_arvore> pq = new PriorityQueue<>(1000, (a, b) -> (a.custo + a.nivel_arvore) - (b.custo + b.nivel_arvore));
        // Cria um novo nó com as posições de menor custo 
        No_arvore raiz = new No_arvore(inicio, x, y, x, y, 0, null);
        raiz.custo = calculo_dos_custos(inicio, fim);
        pq.add(raiz);
        
        // Enquanto a lista não chegou no final, faça:
        while (!pq.isEmpty()) {
            // Retira-se o elemento mais custoso 
            No_arvore min = pq.poll();
            // Se o custo for zero, o melhor caminho é ele, então basta imprimir
            if (min.custo == 0) {
                imprime_caminho_recursivo(min);
                return;
            }
            
            for (int i = 0; i < 4; i++) {
                // Verifica se a posição lida está dentro dos limites da matriz 
                if (verifica_posicao_matriz(min.x + linha[i], min.y + coluna[i])) {
                    // cria um novo nó na arvore 
                    No_arvore no_filho = new No_arvore(min.matriz, min.x, min.y, min.x + linha[i], min.y + coluna[i], min.nivel_arvore + 1, min);
                    // calcula o custo 
                    no_filho.custo = calculo_dos_custos(no_filho.matriz, fim);
                    // adiciona ele 
                    pq.add(no_filho);
                }
            }
        }
    }
    // MAIN DO PROGRAMA
    public static void main(String[] args) {
        // Define estado inicial e final
        int[][] inicio = {{1, 8, 2}, {0, 4, 3}, {7, 6, 5}};
        int[][] fim = {{1, 2, 3}, {4, 5, 6}, {7, 8, 0}};

        // Inicia a coordenada
        int x = 1, y = 0;
        // Chama a classe 
        quebra_cabeca jogo = new quebra_cabeca();
        // Passa os estados e a posição deles 
        // Caso os dados estejam incompletos, recusa 
        if (jogo.sequencia(inicio)) {
            jogo.Resolucao(inicio, fim, x, y);
        } else {
            System.out.println("O modelo inicial não é possivel de resolver");
        }
    }

}
